<?php

/**
 * Guess the celebrity Application
 *
 * This is a fun application
 * 
 *
 * @author      raju mazumder <rajuniit@gmail.com>
 * @package     Application
 * @copyright   2008-2009 raju mazumder
 * @link        http://stylephp.com
 * @since       Version 1.0
 */
 
 



// Database configuration


$dbconfig['db']     = 'quran';
$dbconfig['host']   = 'localhost';
$dbconfig['user']   = 'root';
$dbconfig['pass']   = '';




?>